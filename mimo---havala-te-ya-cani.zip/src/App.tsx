import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  Sparkles, 
  Smile, 
  Heart, 
  Volume1,
  Loader2,
  Send,
  AlertCircle
} from 'lucide-react';

const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

interface HeartParticle {
  id: number;
  x: number;
  y: number;
  scale: number;
  rotation: number;
}

// 3 Custom Kurdish Voice Cadence configurations using closest tr-TR phonetic profiles
const KURDISH_VOICES = [
  { id: 'duhoki', name: 'میمۆ دهۆکی 🥺💜', lang: 'tr-TR', rate: 1.1, pitch: 0.9, gender: 'male', desc: 'شیرینێ ناڤەندا باژێرێ دهۆکێ' },
  { id: 'zaxo', name: 'میمۆ زاخۆیی ✨', lang: 'tr-TR', rate: 1.15, pitch: 0.85, gender: 'male', desc: 'شیرینێ زاخۆ' },
  { id: 'kech', name: 'میمۆ کچا دهۆکێ 🥰', lang: 'tr-TR', rate: 1.0, pitch: 1.2, gender: 'female', desc: 'کچا هەرە دەلال و شیرین ل دهۆکێ' }
];

export default function App() {
  // Navigation & Core States
  const [username, setUsername] = useState<string>(() => {
    return localStorage.getItem('mimo_username') || '';
  });
  const [usernameInput, setUsernameInput] = useState<string>('');

  // Selected Kurdish voice cadence ID
  const [activeVoiceId, setActiveVoiceId] = useState<string>(() => {
    return localStorage.getItem('mimo_active_voice_id') || 'duhoki';
  });

  // Robot emotions & visuals
  const [emotion, setEmotion] = useState<'idle' | 'listening' | 'speaking' | 'thinking' | 'love' | 'sad'>('idle');
  const [isBlinking, setIsBlinking] = useState<boolean>(false);
  const [mouthHeight, setMouthHeight] = useState<number>(2); // Speech mouth scale (2px to 14px)

  // Transcription text overlay (Shown ONLY when user says "binivise", "nvisar", etc)
  const [textOverlay, setTextOverlay] = useState<string>('');
  const [showTextOverlay, setShowTextOverlay] = useState<boolean>(false);
  const textTimeoutRef = useRef<any>(null);

  // Active Listening Timer variables
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const timerIntervalRef = useRef<any>(null);

  // Debugging & Permission Diagnostic Panel
  const [micStatus, setMicStatus] = useState<'unknown' | 'ready' | 'blocked' | 'error'>('unknown');
  const [debugError, setDebugError] = useState<string>('');

  // Interactive Particles
  const [hearts, setHearts] = useState<HeartParticle[]>([]);

  // Voice Engine State
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [recognizedText, setRecognizedText] = useState<string>(() => '');
  const [inputText, setInputText] = useState<string>('');

  const recognitionRef = useRef<any>(null);
  const mouthTimerRef = useRef<any>(null);
  const blinkTimerRef = useRef<any>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Sync active voice to localstorage and set document title
  useEffect(() => {
    localStorage.setItem('mimo_active_voice_id', activeVoiceId);
  }, [activeVoiceId]);

  // Set cute Mimo document title on load
  useEffect(() => {
    document.title = "Mimo 💜";
  }, []);

  // Verify permission status initially
  useEffect(() => {
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions.query({ name: 'microphone' as any })
        .then((permissionStatus) => {
          if (permissionStatus.state === 'granted') {
            setMicStatus('ready');
          } else if (permissionStatus.state === 'denied') {
            setMicStatus('blocked');
          } else {
            setMicStatus('unknown');
          }
          permissionStatus.onchange = () => {
            if (permissionStatus.state === 'granted') {
              setMicStatus('ready');
              setDebugError('');
            } else if (permissionStatus.state === 'denied') {
              setMicStatus('blocked');
            }
          };
        })
          .catch(() => {});
    }
  }, []);

  // Save/load username
  useEffect(() => {
    if (username) {
      localStorage.setItem('mimo_username', username);
    }
  }, [username]);

  // Clean timeouts on unmount
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
      if (blinkTimerRef.current) clearInterval(blinkTimerRef.current);
      if (mouthTimerRef.current) clearInterval(mouthTimerRef.current);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, []);

  // Robot eyes blinking loop
  useEffect(() => {
    const triggerBlink = () => {
      setIsBlinking(true);
      setTimeout(() => {
        setIsBlinking(false);
      }, 150);
    };

    blinkTimerRef.current = setInterval(() => {
      if (Math.random() > 0.25) {
        triggerBlink();
      }
    }, 3200);

    return () => {
      if (blinkTimerRef.current) clearInterval(blinkTimerRef.current);
    };
  }, []);

  // Mouth motion sync when speaking
  useEffect(() => {
    if (isSpeaking && emotion === 'speaking') {
      mouthTimerRef.current = setInterval(() => {
        setMouthHeight(Math.floor(2 + Math.random() * 12));
      }, 90);
    } else {
      if (mouthTimerRef.current) clearInterval(mouthTimerRef.current);
      setMouthHeight(2);
    }

    return () => {
      if (mouthTimerRef.current) clearInterval(mouthTimerRef.current);
    };
  }, [isSpeaking, emotion]);

  // Real-time Canvas Waveform oscillation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const renderWave = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      
      let color = 'rgba(34, 211, 238, 0.4)'; // Cyan idle
      let wavesCount = 3;
      let amplitude = 6;
      let speed = 0.05;

      if (isListening) {
        color = 'rgba(239, 68, 68, 0.75)'; // Red pulsing on toggle recording
        wavesCount = 6;
        amplitude = 25;
        speed = 0.24;
      } else if (isSpeaking) {
        color = 'rgba(168, 85, 247, 0.6)'; // Purple speaking waves
        wavesCount = 4;
        amplitude = mouthHeight * 1.6;
        speed = 0.14;
      } else if (emotion === 'thinking') {
        color = 'rgba(234, 179, 8, 0.5)'; // Yellow thinking waves
        wavesCount = 2;
        amplitude = 10;
        speed = 0.04;
      }

      ctx.lineWidth = 2.5;

      for (let w = 0; w < wavesCount; w++) {
        ctx.strokeStyle = w === 0 ? color : color.replace(/[\d.]+\)$/, `${0.25 / w})`);
        ctx.beginPath();
        
        const currentPhase = phase + (w * Math.PI / 2);
        for (let x = 0; x < width; x++) {
          const y = height / 2 + Math.sin((x / (45 + w * 12)) + currentPhase) * amplitude;
          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }

      phase += speed;
      animId = requestAnimationFrame(renderWave);
    };

    renderWave();
    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isListening, isSpeaking, emotion, mouthHeight]);

  // System Sound feedback
  const playSoundFX = (type: 'beep' | 'start' | 'success' | 'love') => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'beep') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.12);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + 0.12);
      } else if (type === 'start') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(400, audioCtx.currentTime);
        osc.frequency.setValueAtTime(600, audioCtx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.18);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + 0.18);
      } else if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(500, audioCtx.currentTime);
        osc.frequency.setValueAtTime(750, audioCtx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + 0.2);
      } else if (type === 'love') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, audioCtx.currentTime);
        osc.frequency.setValueAtTime(900, audioCtx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + 0.25);
      }
    } catch(e) {}
  };

  // Spark hearts burst
  const spawnHearts = () => {
    playSoundFX('love');
    const newHearts = Array.from({ length: 10 }).map((_, i) => ({
      id: Date.now() + i,
      x: 35 + Math.random() * 30,
      y: 40 + Math.random() * 15,
      scale: 0.5 + Math.random() * 0.9,
      rotation: Math.random() * 360 - 180,
    }));
    setHearts(prev => [...prev, ...newHearts]);
    setTimeout(() => {
      setHearts(prev => prev.filter(h => !newHearts.find(nh => nh.id === h.id)));
    }, 1200);
  };

  // Helper to transliterate Kurdish words to sound perfectly phonetic with a Turkish TTS engine
  const transliterateKurdishToPhoneticTurkish = (text: string): string => {
    // Detect if text contains Arabic Kurdish characters
    const hasArabic = /[\u0600-\u06FF]/.test(text);
    let latinText = text;
    if (hasArabic) {
      // Convert Arabic Kurdish script to Latin script phonetically first
      latinText = latinText
        .replace(/ئەز/g, 'ez')
        .replace(/تۆ/g, 'tu')
        .replace(/تو/g, 'tu')
        .replace(/ئارە والا/g, 'are vala')
        .replace(/ئارەولا/g, 'are vala')
        .replace(/جانم/g, 'canim')
        .replace(/عەزیزم/g, 'azizem')
        .replace(/عەزیزێ من/g, 'azize min')
        .replace(/بەلێ/g, 'bele')
        .replace(/میمۆ/g, 'mimo')
        .replace(/شیرین/g, 'şirin')
        .replace(/شîرîن/g, 'şirin')
        .replace(/دهۆک/g, 'duhok')
        .replace(/زاخۆ/g, 'zaxo')
        .replace(/گەلەک/g, 'gelek')
        .replace(/چەوانی/g, 'çavani')
        .replace(/باشم/g, 'başım')
        .replace(/کچ/g, 'kıç')
        .replace(/هەڤال/g, 'heval');

      const charMap: Record<string, string> = {
        'ئ': '',
        'ا': 'a',
        'آ': 'a',
        'ب': 'b',
        'پ': 'p',
        'ت': 't',
        'ج': 'c',
        'چ': 'ç',
        'ح': 'h',
        'خ': 'h',
        'د': 'd',
        'ر': 'r',
        'ڕ': 'r',
        'ز': 'z',
        'ژ': 'j',
        'س': 's',
        'ش': 'ş',
        'ع': 'a',
        'غ': 'g',
        'ف': 'f',
        'ڤ': 'v',
        'ق': 'g',
        'ک': 'k',
        'گ': 'g',
        'ل': 'l',
        'ڵ': 'l',
        'م': 'm',
        'ن': 'n',
        'ۆ': 'o',
        'ێ': 'e',
        'ە': 'e',
        'ی': 'i',
        'ى': 'i',
        'ي': 'i',
      };

      let builtText = '';
      for (let i = 0; i < latinText.length; i++) {
        const char = latinText[i];
        if (char === 'و') {
          const prev = i > 0 ? latinText[i-1] : ' ';
          const next = i < latinText.length - 1 ? latinText[i+1] : ' ';
          const vowels = ['ا', 'ە', 'ێ', 'ی', 'ۆ', 'a', 'e', 'i', 'o', 'u'];
          if (vowels.includes(prev) || vowels.includes(next)) {
            builtText += 'v';
          } else {
            builtText += 'u';
          }
        } else if (charMap[char] !== undefined) {
          builtText += charMap[char];
        } else {
          builtText += char;
        }
      }
      latinText = builtText;
    }

    return latinText
      .replace(/x/g, 'h') 
      .replace(/X/g, 'H')
      .replace(/w/g, 'v') 
      .replace(/W/g, 'V')
      .replace(/ê/g, 'e') 
      .replace(/Ê/g, 'E')
      .replace(/î/g, 'i') 
      .replace(/Î/g, 'İ')
      .replace(/û/g, 'u')
      .replace(/Û/g, 'U')
      .replace(/çawa/gi, 'çava')
      .replace(/chawani/gi, 'çavanî')
      .replace(/chawane/gi, 'çavane')
      .replace(/bashi/gi, 'başî')
      .replace(/kuroo/gi, 'kuro')
      .replace(/kuro/gi, 'kuro')
      .replace(/kurr/gi, 'kur')
      .replace(/are/gi, 'are')
      .replace(/wala/gi, 'vele')
      .replace(/de were/gi, 'de vere')
      .replace(/de fere/gi, 'de vere')
      .replace(/wey lo/gi, 'vey lo')
      .replace(/oy lo/gi, 'oy lo')
      .replace(/cho/gi, 'ço')
      .replace(/de billa/gi, 'de billa')
      .replace(/qizik dikim/gi, 'gızık dıkım')
      .replace(/pesimam/gi, 'pısmam')
      .replace(/pismam/gi, 'pısmam')
      .replace(/rasti/gi, 'rastî')
      .replace(/şîrîn/gi, 'şirin')
      .replace(/shirin/gi, 'şirin')
      .replace(/ez/g, 'ez')
      .replace(/te/g, 'te');
  };

  // Speaks answer text using browser Speech Synthesis
  const speakText = (text: string) => {
    try {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);

      let filteredText = text;
      
      // Client-side Farsi filter & language detection
      const farsiWords = ['چطوری', 'خوبی', 'مرسی', 'چقدر', 'تشکر', 'ممنون', 'خوبم', 'chetori', 'khobi', 'merci', 'cheghadr', 'moteshaker', 'mamnoon'];
      const hasFarsi = farsiWords.some(fw => filteredText.toLowerCase().includes(fw));
      
      if (hasFarsi) {
        const hasArabic = /[\u0600-\u06FF]/.test(filteredText);
        if (hasArabic) {
          filteredText = "ئارە والا جانم ئەز ب بادینی باخڤم، نەک فارسی! چەوانی تو؟ 🥺💜";
        } else {
          filteredText = "Are wala janim ez bi Badînî diaxivim, ne Farsî! Chawani tu? 🥺💜";
        }
      }

      const cleanedText = filteredText
        .replace(/[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD00-\uDFFF]/g, "") // remove emoji
        .trim();

      if (!cleanedText) return;

      const voices = window.speechSynthesis.getVoices();
      
      // Get the currently selected Kurdish voice configuration
      const selectedVoiceConfig = KURDISH_VOICES.find(v => v.id === activeVoiceId) || KURDISH_VOICES[0];
      
      // Try to find a Turkish voice as fallback
      let matchedVoice = voices.find(v => v.lang.startsWith('tr'));
      
      // If female voice is selected, try to find a female Turkish voice
      if (selectedVoiceConfig.gender === 'female') {
        const femaleVoice = voices.find(v => 
          v.lang.startsWith('tr') && 
          (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('yelda') || v.name.toLowerCase().includes('seda') || v.name.toLowerCase().includes('google'))
        );
        if (femaleVoice) {
          matchedVoice = femaleVoice;
        }
      }

      // Apply smart phonetic mapping to Turkish voices so they speak with a perfect Badini accent!
      const textToSpeak = transliterateKurdishToPhoneticTurkish(cleanedText);

      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      if (matchedVoice) {
        utterance.voice = matchedVoice;
        utterance.lang = matchedVoice.lang;
      } else {
        utterance.lang = 'tr-TR';
      }

      // Apply the precise rhythmic cadence of the selected voice config!
      utterance.pitch = selectedVoiceConfig.pitch;
      utterance.rate = selectedVoiceConfig.rate;

      utterance.onstart = () => {
        setIsSpeaking(true);
        setEmotion('speaking');
      };

      utterance.onend = () => {
        setIsSpeaking(false);
        setEmotion('idle');
      };

      utterance.onerror = () => {
        setIsSpeaking(false);
        setEmotion('idle');
      };

      window.speechSynthesis.speak(utterance);
    } catch(e) {
      console.error(e);
      setIsSpeaking(false);
      setEmotion('idle');
    }
  };

  // Helper to test speak and unlock TTS with a explicit User Gesture on clicking robot
  const handleRobotTap = () => {
    spawnHearts();
    speakText("ئارە والا جانم چەوانی تو؟ ئەز میمۆ یا تە مە، هەر تشت گەلەک شیرینە! 🥺💜");
  };

  // ONE TAP TO TALK - Start SpeechRecognition Session (State 2)
  const startRecording = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setRecognizedText('');
    setEmotion('listening');

    if (!SpeechRecognition) {
      setDebugError("Browser nakeve! SpeechRecognition blocked. Eger mîkrofon kar nake, binivîse!");
      setEmotion('idle');
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = true; 
      rec.interimResults = false;
      rec.lang = 'ku-IQ';

      rec.onstart = () => {
        setIsListening(true);
        playSoundFX('start');
        
        // Start incremental timer clock
        setRecordingSeconds(0);
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = setInterval(() => {
          setRecordingSeconds(prev => prev + 1);
        }, 1000);
      };

      rec.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setRecognizedText(prev => prev + ' ' + finalTranscript);
        }
      };

      rec.onerror = (err: any) => {
        console.warn('Recognition error:', err);
        setDebugError(`SpeechError: ${err.error}. Eger mîkrofon kar nake, binivîse!`);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
      rec.start();
    } catch(e: any) {
      console.error(e);
      setDebugError(`Error: ${e.message || 'Speech init failed'}`);
    }
  };

  // ONE TAP TO TALK - Stop SpeechRecognition Session (State 3)
  const stopRecording = () => {
    setIsListening(false);
    playSoundFX('beep');

    // Clear timer interval
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    setEmotion('thinking');

    // Submit captured transcript to Gemini after short debounce delay
    setTimeout(() => {
      setRecognizedText(current => {
        if (current && current.trim()) {
          handleSendVoiceMessage(current.trim());
        } else {
          setEmotion('idle');
        }
        return current;
      });
    }, 400);
  };

  // Toggle Voice controller handler
  const handleToggleMic = async (e?: React.SyntheticEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    // Trigger haptic vibration
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }

    // Unlock speechSynthesis on user gesture
    try {
      window.speechSynthesis.cancel();
      const dummyUtterance = new SpeechSynthesisUtterance("");
      window.speechSynthesis.speak(dummyUtterance);
    } catch(err) {}

    if (isListening) {
      stopRecording();
      return;
    }

    // Explicitly request microphone stream to trigger permissions popup!
    try {
      setDebugError('');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setMicStatus('ready');
      stream.getTracks().forEach(track => track.stop());
    } catch (err: any) {
      console.error("Microphone access denied:", err);
      setMicStatus('blocked');
      setDebugError("Microphone destûrê bide! Settings > Site settings > Microphone > Allow");
      return;
    }

    startRecording();
  };

  // Format timer helper: mm:ss
  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // Send voice message transcribing directly to backend
  const handleSendVoiceMessage = async (voiceText: string) => {
    setEmotion('thinking');

    const lowerText = voiceText.toLowerCase();
    const sweetWords = ['shirin', 'delal', 'xosh', 'love', 'bira', 'lo', 'mimo', 'ciwan', 'tu', 'janim', 'azizem', 'canî', 'cani', 'شیرین', 'دەلال', 'خۆش', 'عەزیزم', 'جانم', 'میمۆ', 'جانی', 'تە', 'تو'];
    const triggeredSweet = sweetWords.some(word => lowerText.includes(word));
    
    if (triggeredSweet) {
      setEmotion('love');
      spawnHearts();
    }

    // Check for explicit "write to me" triggers to display text overlay on screen for 5 seconds
    const showTextTriggers = ['binivise', 'nvisar', 'binivise bo min', 'nvisareke', 'ekran', 'nivîsîn', 'بنڤیسە', 'بنووسە', 'بنویسە', 'نڤیسار', 'شاشە'];
    const shouldShowText = showTextTriggers.some(t => lowerText.includes(t));

    try {
      // Call secure Express `/api/chat` route
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: voiceText,
          history: [], // Keep stateless / clean vocal flow
          username: username
        })
      });

      if (!response.ok) throw new Error('API voice call failed');
      const data = await response.json();

      // Handle Text Display overlay for 5 seconds if requested or triggered
      if (shouldShowText || data.text.length < 50) {
        setTextOverlay(`${voiceText} ➔ ${data.text}`);
        setShowTextOverlay(true);
        if (textTimeoutRef.current) clearTimeout(textTimeoutRef.current);
        textTimeoutRef.current = setTimeout(() => {
          setShowTextOverlay(false);
        }, 5000);
      }

      // Change robot emotions based on content
      if (data.text.includes('😍') || data.text.includes('🥰') || triggeredSweet) {
        setEmotion('love');
        spawnHearts();
      } else if (data.text.includes('🥺') || data.text.includes('😭')) {
        setEmotion('sad');
      } else {
        setEmotion('speaking');
      }

      speakText(data.text);
    } catch(e) {
      console.error(e);
      let fallback = 'عەزیزم، شیرینا من! ئینتەرنێتا من هەکەست کێم بوویە! دیسا هەول بدە جانم! 🥺💜';
      if (lowerText.includes('slav') || lowerText.includes('سلاڤ') || lowerText.includes('سلاڤا')) {
        fallback = 'سلاڤ جانم! ئەز میمۆ مە! ئارە والا ئەز ئامادەمە ژ تەرە باخڤم، میمۆ یا تە مە! چەوانی عەزیزم؟ 🥺💜✨';
      }
      setEmotion('speaking');
      speakText(fallback);
    }
  };

  // Submit start card
  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = usernameInput.trim();
    if (!cleanName) return;

    setUsername(cleanName);
    playSoundFX('success');

    // Auto speak initial greeting
    setTimeout(() => {
      speakText(`سلاڤ ${cleanName}! ئەز میمۆ مە! بووکەلەکا جانی یا دهۆکێ مە، میمۆ یا تە مە! ئارە والا جانم، بتنە سەر مایکروفونێ دا کو ئەم ب هەڤڕا باخڤین عەزیزم! 🥺💜✨`);
    }, 600);
  };

  // Logout/Reset User
  const handleLogout = () => {
    if (window.confirm('جانم، تو دخوازی ناڤێ خۆ ژێببەی و بچی لاپەرێ دەستپێکێ؟')) {
      window.speechSynthesis.cancel();
      localStorage.removeItem('mimo_username');
      localStorage.removeItem('mimo_active_voice_id');
      setUsername('');
      setUsernameInput('');
    }
  };

  return (
    <div className="min-h-screen bg-[#061e22] text-slate-100 flex flex-col items-center justify-center p-4 relative overflow-hidden selection:bg-cyan-500/30">
      
      {/* Immersive Teal Background Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#021114] via-[#061e22] to-[#0c3a44] z-0" />

      {/* Heart Particle Layer */}
      {hearts.map(h => (
        <div
          key={h.id}
          className="absolute z-40 text-rose-500 pointer-events-none transition-transform"
          style={{
            left: `${h.x}%`,
            top: `${h.y}%`,
            '--heart-scale': h.scale,
            '--heart-rot': `${h.rotation}deg`,
            animation: 'float-heart 1.2s forwards cubic-bezier(0.1, 0.8, 0.3, 1)',
          } as React.CSSProperties}
        >
          <Heart className="w-7 h-7 fill-rose-500 drop-shadow-[0_0_10px_rgba(244,63,94,0.6)]" />
        </div>
      ))}

      {/* START USER BOARD CARD */}
      {!username ? (
        <div className="max-w-md w-full bg-[#0a1e22]/90 backdrop-blur-xl border border-cyan-800/20 rounded-3xl p-8 shadow-2xl text-center relative z-10 overflow-hidden">
          
          <div className="absolute -top-12 -left-12 w-44 h-44 bg-cyan-500/10 rounded-full blur-2xl" />
          <div className="absolute -bottom-12 -right-12 w-44 h-44 bg-purple-500/10 rounded-full blur-2xl" />

          <div className="flex flex-col items-center mb-6">
            {/* Sleeping eyes SVG decorative container */}
            <div className="w-20 h-20 bg-slate-950 rounded-full flex items-center justify-center border border-cyan-500/25 mb-4 animate-bounce">
              <svg width="40" height="20" viewBox="0 0 40 20">
                <path d="M 5,10 Q 10,18 15,10" fill="none" stroke="#00f5ff" strokeWidth="3" strokeLinecap="round" />
                <path d="M 25,10 Q 30,18 35,10" fill="none" stroke="#00f5ff" strokeWidth="3" strokeLinecap="round" />
              </svg>
            </div>

            <h1 className="text-3xl font-black bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
              Mimo Robot 🥺💜
            </h1>
            <p className="text-[10px] font-black text-pink-400 uppercase tracking-widest mt-1">
              بۆکەلەکا جانی · هەڤالێ دەنگی 🥺💜
            </p>
            <p className="text-xs text-slate-400 mt-4 leading-relaxed max-w-xs">
              سیستەما هەڤالێ دەنگی یێ شیرین! ب تەمامی ب دەنگە. ژ کەرەما خۆ ناڤێ خۆ بنڤیسە دا کو دەستپێ بکەین جانم!
            </p>
          </div>

          <form onSubmit={handleStart} className="space-y-4">
            <input
              type="text"
              required
              value={usernameInput}
              onChange={(e) => setUsernameInput(e.target.value)}
              placeholder="ناڤێ تە چییە عەزیزم؟ (بۆ نموونە ئالان)"
              className="w-full bg-[#020b0d] border border-pink-900/40 text-slate-100 placeholder-slate-500 rounded-2xl py-3.5 px-5 focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-500 text-sm font-medium transition-all"
              maxLength={25}
            />
            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-400 hover:to-purple-400 text-slate-950 font-black rounded-2xl text-xs tracking-wider uppercase transition-all shadow-lg transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
            >
              دەستپێ بکە عەزیزم! 🚀
            </button>
          </form>
        </div>
      ) : (

        /* VOICE CHAT ONLY INTERFACE DISPLAY */
        <div className="w-full max-w-md h-[740px] bg-[#22072a]/40 backdrop-blur-xl border border-pink-900/20 rounded-3xl p-5 shadow-2xl flex flex-col justify-between relative z-10 transition-all overflow-hidden">
          
          {/* HEADER PORTION */}
          <div className="flex items-center justify-between border-b border-pink-900/10 pb-3 shrink-0">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-pink-500 animate-ping" />
              <div>
                <h1 id="logo" className="text-md font-black text-white leading-none">MIMO</h1>
                <span className="text-[9px] text-pink-400 font-bold tracking-widest uppercase">میمۆ یا تە یە 🥺💜</span>
              </div>
            </div>

            {/* Tap to Talk Status Badge */}
            <div className="text-[10px] font-bold text-slate-400 bg-slate-950/40 px-3 py-1.5 rounded-full border border-cyan-900/20 flex items-center gap-1.5">
              {isListening ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <span className="text-red-400 font-mono tracking-wider">{formatTimer(recordingSeconds)}</span>
                </>
              ) : emotion === 'thinking' ? (
                <span className="text-yellow-400 flex items-center gap-1 animate-pulse">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  میمۆ هزرێن خوو دکەت...
                </span>
              ) : (
                <span className={micStatus === 'ready' ? 'text-cyan-400' : 'text-slate-500'}>
                  Mic: {micStatus === 'ready' ? '✅ Ready' : micStatus === 'blocked' ? '❌ Blocked' : '⏳ Checking'}
                </span>
              )}
            </div>

            {/* Simple Reset Name Button */}
            <button
              onClick={handleLogout}
              className="text-[10px] font-bold text-slate-400 hover:text-white bg-slate-950/40 border border-cyan-900/20 px-2.5 py-1.5 rounded-lg"
              title="Change Username"
            >
              نوهکرنا ناڤی
            </button>
          </div>

          {/* DYNAMIC KURDISH CHAT VOICES SELECTION BAR */}
          <div className="py-2.5 bg-slate-950/40 rounded-xl border border-pink-500/10 px-3 flex flex-col gap-2 shrink-0">
            <span className="text-[9.5px] text-pink-400 font-black uppercase tracking-widest block text-center">دەنکێ میمۆ (کادانسا دەنگی)</span>
            <div className="grid grid-cols-3 gap-1.5">
              {KURDISH_VOICES.map((voice) => (
                <button
                  key={voice.id}
                  type="button"
                  onClick={() => { setActiveVoiceId(voice.id); playSoundFX('beep'); }}
                  className={`py-2 px-1 rounded-lg text-[10px] font-bold tracking-tight transition-all cursor-pointer flex flex-col items-center justify-center border text-center ${
                    activeVoiceId === voice.id
                      ? 'bg-[#4c0f3a] text-white border-pink-400 shadow-md shadow-pink-500/10'
                      : 'bg-slate-900/50 text-slate-400 border-transparent hover:border-pink-900/30'
                  }`}
                  title={voice.desc}
                >
                  <span className="truncate w-full font-bold">{voice.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* MAIN CENTER: THE VOICE-ONLY ROBOT DISPLAY */}
          <div className="flex-1 flex flex-col items-center justify-center relative">
            
            {/* TEXT DIALOGUE OVERLAY (Shown for 5 seconds when requested "binivise") */}
            {showTextOverlay && (
              <div className="absolute inset-x-2 top-2 z-30 p-4 bg-slate-950/90 backdrop-blur-lg border border-cyan-500/25 rounded-2xl shadow-2xl text-center animate-in fade-in duration-300">
                <span className="text-[9px] text-cyan-400 font-extrabold uppercase tracking-widest block mb-1">نڤیسار (دەقێ سەر شاشێ)</span>
                <p className="text-xs text-slate-200 leading-relaxed font-semibold italic">{textOverlay}</p>
              </div>
            )}

            {/* Cute MIMO robot SVG design */}
            <div 
              className="w-56 h-56 flex items-center justify-center relative select-none cursor-pointer group"
              onClick={handleRobotTap}
              title="Klik bike bo ceribandina dengî û dila!"
            >
              <svg
                width="210"
                height="240"
                viewBox="0 0 200 200"
                className="group-hover:scale-105 transition-transform"
                style={{
                  animation: isListening 
                    ? 'float-active 1.4s infinite ease-in-out' 
                    : 'float-active 3.2s infinite ease-in-out'
                }}
              >
                <defs>
                  <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Hands */}
                <path d="M 30,125 Q 12,130 22,145 M 170,125 Q 188,130 178,145" stroke="#e2e8f0" strokeWidth="5" strokeLinecap="round" fill="none" />

                {/* Body */}
                <rect x="52" y="105" width="96" height="70" rx="42" fill="#ffffff" stroke="#cbd5e1" strokeWidth="2" />
                <circle cx="100" cy="140" r="11" fill={emotion === 'love' ? '#ff2d55' : '#ff2d7a'} filter="url(#glow)" />

                {/* Ears / Antennas */}
                <path d="M 30,70 L 15,50 M 170,70 L 185,50" stroke="#cbd5e1" strokeWidth="3.5" />
                <circle cx="15" cy="50" r="5" fill="#ff2d7a" filter="url(#glow)" />
                <circle cx="185" cy="50" r="5" fill="#ff2d7a" filter="url(#glow)" />

                {/* Head Chassis */}
                <rect x="36" y="32" width="128" height="84" rx="28" fill="#ffffff" stroke="#cbd5e1" strokeWidth="2.5" />
                
                {/* Black Screen */}
                <rect x="48" y="42" width="104" height="64" rx="14" fill="#080f18" />

                {/* Blushing cheeks */}
                {(emotion === 'love' || emotion === 'speaking') && (
                  <>
                    <circle cx="62" cy="85" r="5" fill="#ff2d55" fillOpacity="0.4" />
                    <circle cx="138" cy="85" r="5" fill="#ff2d55" fillOpacity="0.4" />
                  </>
                )}

                {/* Glowing Eyes */}
                {isBlinking ? (
                  <>
                    <line x1="56" y1="70" x2="74" y2="70" stroke="#ff2d7a" strokeWidth="4.5" strokeLinecap="round" filter="url(#glow)" />
                    <line x1="126" y1="70" x2="144" y2="70" stroke="#ff2d7a" strokeWidth="4.5" strokeLinecap="round" filter="url(#glow)" />
                  </>
                ) : emotion === 'love' ? (
                  <>
                    <path d="M 66,74 C 63,67 52,67 52,74 C 52,81 66,90 66,90 C 66,90 80,81 80,74 C 80,67 69,67 66,74 Z" fill="#ff2d55" filter="url(#glow)" />
                    <path d="M 134,74 C 131,67 120,67 120,74 C 120,81 134,90 134,90 C 134,90 148,81 148,74 C 148,67 137,67 134,74 Z" fill="#ff2d55" filter="url(#glow)" />
                  </>
                ) : emotion === 'sad' ? (
                  <>
                    <path d="M 54,76 C 58,68 72,68 76,76" fill="none" stroke="#38bdf8" strokeWidth="4" strokeLinecap="round" filter="url(#glow)" />
                    <path d="M 124,76 C 128,68 142,68 146,76" fill="none" stroke="#38bdf8" strokeWidth="4" strokeLinecap="round" filter="url(#glow)" />
                  </>
                ) : emotion === 'thinking' ? (
                  <>
                    <circle cx="70" cy="62" r="8.5" fill="#ff79c6" filter="url(#glow)" />
                    <circle cx="138" cy="62" r="8.5" fill="#ff79c6" filter="url(#glow)" />
                  </>
                ) : (
                  <>
                    <circle cx="66" cy="68" r={isListening ? "11.5" : "9.5"} fill="#ff2d7a" filter="url(#glow)" />
                    <circle cx="134" cy="68" r={isListening ? "11.5" : "9.5"} fill="#ff2d7a" filter="url(#glow)" />
                  </>
                )}

                {/* Animated speaking mouth */}
                {isSpeaking ? (
                  <ellipse cx="100" cy="85" rx="6.5" ry={mouthHeight / 2} fill="#ff2d7a" filter="url(#glow)" />
                ) : (
                  <path d="M 94,84 Q 100,91 106,84" fill="none" stroke="#ff2d7a" strokeWidth="3" strokeLinecap="round" filter="url(#glow)" />
                )}
              </svg>

              {/* Pink shadow disc */}
              <div className="absolute bottom-4 w-40 h-4 bg-pink-500/10 rounded-full blur-md" />
            </div>

            {/* STATUS CAPTION UNDER ROBOT */}
            <div className="text-center mt-1 z-10 px-4">
              <span className="text-xs font-bold text-pink-400 block mb-1">
                {isListening 
                  ? "🔴 گوهداریا تە دکەم... تاپ بکە بو راوستاندنێ 🎤" 
                  : isSpeaking 
                    ? "🔊 میمۆ بەرسڤێ ددەت... 🥺💜" 
                    : emotion === 'thinking'
                      ? "⏳ میمۆ هزرێن خوو دکەت..."
                      : "تاپ بکە و باخڤە جانم... 🥺💜"
                }
              </span>
              <p className="text-[11px] text-slate-400 max-w-xs leading-normal">
                {isListening 
                  ? "ژ کەرەما خۆ ب دلگەرمی باخڤە جانم، من هەر تشت تومارکر!" 
                  : "مایکروفونێ جارەکێ بتپە دا کو باخڤی، یان ژی بو تاقیکردنا دەنگی ل سەر میمۆیێ بتپە!"
                }
              </p>

              {/* Glowing Voice Test Button */}
              {!isListening && (
                <button
                  type="button"
                  onClick={handleRobotTap}
                  className="mt-2 px-4 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-400 text-[10px] font-extrabold uppercase tracking-wider hover:bg-pink-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5 mx-auto cursor-pointer shadow-md shadow-pink-500/5"
                >
                  <Volume1 className="w-3.5 h-3.5" />
                  گوهداریا دەنگێ میمۆ بکە 🔊 (تاقیکرنا دەنگی)
                </button>
              )}
            </div>

          </div>

          {/* LOWER CONTROLS: WAVEFORM + TOGGLE TAP MIC BUTTON */}
          <div className="w-full flex flex-col items-center gap-3 shrink-0 border-t border-pink-900/10 pt-3">
            
            {/* DEBUG ERROR OR PERMISSION ALERT CONTAINER */}
            {debugError && (
              <div className="w-full bg-red-950/40 border border-red-500/30 rounded-xl px-3 py-2 text-red-400 text-[10.5px] leading-relaxed flex flex-col gap-1 animate-pulse">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <span>{debugError}</span>
                </div>
                <button
                  type="button"
                  onClick={handleToggleMic}
                  className="text-[10px] font-bold text-pink-400 hover:text-pink-300 transition-colors text-left underline cursor-pointer pl-6 mt-0.5"
                >
                  دوبارە تاقیکرنەوە 🔄 (مۆڵەتێ بدە)
                </button>
              </div>
            )}

            {/* OSCILLOSCOPE WAVEFORM CANVAS */}
            <div className="w-full h-11 overflow-hidden relative rounded-xl bg-slate-950/50 border border-pink-900/25 flex items-center justify-center">
              <canvas 
                ref={canvasRef} 
                width="380" 
                height="44"
                className="w-full h-full object-cover"
              />
            </div>

            {/* SINGLE BIG TOGGLE VOICE-RECORD MICROPHONE BUTTON */}
            <div className="relative flex flex-col items-center justify-center w-full">
              
              {/* Outer pulsing glow frame when recording */}
              {isListening && (
                <div className="absolute w-26 h-26 bg-red-500/20 rounded-full animate-ping pointer-events-none" />
              )}
              
              <button
                onClick={handleToggleMic}
                onTouchStart={handleToggleMic}
                className={`w-18 h-18 rounded-full flex flex-col items-center justify-center transition-all duration-300 border-4 select-none relative z-10 shadow-2xl active:scale-90 hover:scale-105 ${
                  isListening
                    ? 'bg-gradient-to-tr from-red-600 to-rose-600 border-red-400 text-white shadow-red-500/30'
                    : emotion === 'thinking'
                      ? 'bg-slate-800 border-yellow-500/50 text-yellow-400 cursor-wait'
                      : 'bg-[#150318] border-pink-500/50 text-pink-400 hover:border-pink-400'
                }`}
                style={{ touchAction: 'none' }}
              >
                {emotion === 'thinking' ? (
                  <Loader2 className="w-7 h-7 animate-spin" />
                ) : (
                  <Mic className="w-7 h-7" />
                )}
              </button>

              <span className="text-[10px] text-slate-400 mt-1 font-bold tracking-tight">
                {isListening ? "بو راوستاندنێ بتپە" : "بو باخڤینێ بتپە"}
              </span>

            </div>

            {/* FALLBACK INLINE TEXT INPUT PANEL (Highlighted automatically if Mic is blocked) */}
            <form 
              onSubmit={(e) => { e.preventDefault(); if (inputText.trim()) handleSendVoiceMessage(inputText); }}
              className={`w-full flex items-center gap-2 bg-[#0c020d] border rounded-xl px-2.5 py-2 mt-1 transition-all ${
                micStatus === 'blocked'
                  ? 'border-pink-500 shadow-md shadow-pink-500/10 animate-pulse'
                  : 'border-pink-900/30'
              }`}
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  micStatus === 'blocked'
                    ? "مایکروفون گرتى یە، لێ تو دشێی ل ڤێرە بنڤیسی عەزیزم! ✍️💜"
                    : "ئەگەر مایکروفون کار نەکەت، ل ڤێرە بنڤیسە جانم... ✍️💜"
                }
                className="flex-1 bg-transparent border-none text-[11.5px] text-slate-100 placeholder-slate-400 focus:outline-none pl-1 py-0.5"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className={`p-1.5 rounded-lg ${
                  inputText.trim() 
                    ? 'bg-pink-500 text-slate-950 hover:bg-pink-400 scale-105 shadow-md shadow-pink-500/20' 
                    : 'text-slate-600'
                } transition-all cursor-pointer`}
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

          </div>

        </div>
      )}

      {/* Embedded Animations directly loaded */}
      <style>{`
        @keyframes float-active {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-7px) rotate(1deg); }
        }
        @keyframes float-heart {
          0% {
            transform: translateY(0) scale(var(--heart-scale)) rotate(var(--heart-rot));
            opacity: 1;
          }
          100% {
            transform: translateY(-150px) scale(0) rotate(calc(var(--heart-rot) + 45deg));
            opacity: 0;
          }
        }
      `}</style>

    </div>
  );
}
